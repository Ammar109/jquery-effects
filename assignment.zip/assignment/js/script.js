$(function() {

    $(".red-box").click(function(){
        var currentOpacity = $(this).css("opacity");
        if (currentOpacity>0.2) {
        $(this).fadeTo(500,currentOpacity-0.2);
    }
    else {
        $(this).fadeTo(500,1);
    }
    });
    $(".blue-box").hover(function(){
        var blueBox = $(".blue-box");
        blueBox.mouseenter(function(){
            $(this).stop().fadeTo(500,0.2)
        });
        blueBox.mouseleave(function(){
            $(this).stop().fadeTo(500,1)
        });

    })
    $(".green-box").hover(function(){
        var blueBox = $(".green-box");
        blueBox.hover(function(){
            $(this).css("background-color","red");
        },function(){
            $(this).css("background-color","green");
        });
    })
    

});